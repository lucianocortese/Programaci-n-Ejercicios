#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include "input.h"
#include "socios.h"
#define TAM_SOC 10
#define TAM_LIB 10
#define TAM_AUT 10
#define TAM_PRE 10



int main()
{

    eAutores autores[TAM_AUT];
    eLibros libros[TAM_LIB];
    eSocios socios [TAM_SOC];
    ePrestamos prestamos[TAM_PRE];

    inicializarSocios(socios, TAM_SOC);
    inicializarPrestamos (prestamos, TAM_PRE);

    int menu;
    int contId=0;
    int contIdPre=0;
    char continuar='N';
    char respSubMenu='N';
    int menuInformes;
    hardcodeo (autores, TAM_AUT, libros, TAM_LIB);



    do{

    printf("--------- ABM biblioteca-------\n");
    printf("1- Alta socio \n");
    printf("2- Modificar socio \n");
    printf("3- Baja socio \n");
    printf("4- Listar socios \n");
    printf("5- Listar libros \n");
    printf("6- Listar autores \n");
    printf("7- Alta prestamos\n");
    printf("8- Menu informes\n");
    printf("0- Salir\n");

        getInt(&menu, "Ingrese una opcion: ", "No es una opcion valida, intente nuevamente",0,8);

        switch (menu){
            case 1:
                contId=altaSocio(socios, TAM_SOC, contId);
                break;
            case 2:
                modificarSocios(socios,TAM_SOC);
                break;
            case 3:
                bajaSocio(socios,TAM_SOC);
                break;
            case 4:
                ordenarPorApellido(socios,TAM_SOC);
                mostrarSocios (socios,TAM_SOC);
                break;
            case 5:
                ordenarPorTitulo (libros, TAM_LIB);
                mostrarLibros(libros, TAM_LIB);
                break;
            case 6:
                ordenarAutoresPorApellido(autores,TAM_AUT);
                mostrarAutores(autores, TAM_AUT);
                break;
            case 7:
                contIdPre=altaPrestamos(prestamos, TAM_PRE, contIdPre);
                break;
            case 8:

                do{
                printf("------Submenu informes---\n");
                printf("1- Informar total general y promedio diario \n");
                printf("2- Informar los dias que supero el promedio \n");
                printf("3- Listar socios que solicitaron el prestamo de un libro \n");
                printf ("4- Listar libros retirados por un socio\n");
                printf ("5- El libro menos solicitado\n");
                printf ("6- Socio con mas prestamos\n");
                printf ("7- Listar libros prestados en una fecha\n");
                printf ("8- Listar socios que solicitaron prestamo en una fecha\n");
                printf ("9- Ordenar Libros\n");
                printf("0- Volver\n");
                printf("Ingrese una opcion: \n");

                scanf("%d",&menuInformes);

                switch(menuInformes){
                case 1:
                    informarTotalYPromedio(prestamos, TAM_PRE);
                    break;
                case 2:
                    informarDiasSuperandoPromedio(prestamos, TAM_PRE);
                    break;
                case 3:
                    listarSociosPorLibro(socios, TAM_SOC,prestamos, TAM_PRE, libros,TAM_LIB);
                    break;
                case 4:
                    listarLibrosPorSocio(prestamos,TAM_PRE,socios,TAM_SOC,libros,TAM_LIB);
                    break;
                case 5:
                    informarLibroMenosPrestado(libros, TAM_LIB, prestamos, TAM_PRE);
                    break;
                case 6:
                    socioConMasPrestamos(socios, TAM_SOC, prestamos, TAM_PRE);
                    break;
                case 7:
                    listarLibrosPorFecha(prestamos, TAM_PRE, libros, TAM_LIB);
                    break;
                case 8:
                    listarSociosPorFecha(prestamos, TAM_PRE, socios, TAM_SOC);
                    break;
                case 9:
                    ordenarPorTituloInverso (libros, TAM_LIB);
                    mostrarLibros(libros, TAM_LIB);
                    break;
                case 0:
                    getChar(&respSubMenu, "Desea volver? (S/N)", "No es una opcion valida, probemos nuevamente", 'S', 'N');
                    break;
                default:
                    printf("No es una opcion valida");
                    break;
                }
                }while(respSubMenu=='N');
            case 0:
                getChar(&continuar, "Desea salir? (S/N)", "No es una opcion valida, probemos nuevamente", 'S', 'N');
                break;
                }
    }while (continuar=='N');

    return 0;
}

