/**
 * \brief Pausa el programa hasta que el usuario presione una tecla
 *
 */
void pausa ();
/**
 * \brief Limpia la pantalla.
 *
 */
void clscreen ();
